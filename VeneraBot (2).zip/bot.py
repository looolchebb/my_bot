from telethon.sync import TelegramClient, events

api_id = 21800053
api_hash = '59f47ce469b1874fbba2adcaf2ee7212'

with TelegramClient('session', api_id, api_hash) as client:

    @client.on(events.NewMessage)
    async def handler(event):
        if 'ритуал' in event.raw_text.lower():
            await event.reply("Здравствуйте! Я Венера, практик, я специализируюсь только на ритуалах. Вот мой тг канал с отзывами и прайсом: @vvenus_tarot. Буду рада подписке и реакциям!")

    client.run_until_disconnected()
